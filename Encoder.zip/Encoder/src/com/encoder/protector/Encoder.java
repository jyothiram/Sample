package com.encoder.protector;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Properties;
public class Encoder
{
	Cipher eCipher,dCipher;
	String algorithm="AES";
	byte[] byt=new byte[] {'T','h','e','h','a','n','e','e','f','i','s','G','r','e','a','t'};
	Key generateKey()
	{
		
		return new SecretKeySpec(byt,algorithm);
		
	}
	public String encrypt(String data) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
	{
		Key key = generateKey();
        eCipher = Cipher.getInstance(algorithm);
        eCipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptValue = eCipher.doFinal(data.getBytes());
        return Base64.getEncoder().encodeToString(encryptValue);
	}
	public String decrypt(String data) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException
	{
		Key key = generateKey();
        dCipher = Cipher.getInstance(algorithm);
        dCipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decodeValue = Base64.getDecoder().decode(data);
        byte[] decryptValue = dCipher.doFinal(decodeValue);
        return new String(decryptValue);
	}
	public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, IOException 
	{	
		Encoder encode=new Encoder();
		Properties property=new Properties();
		FileReader fileread=new FileReader("Data.properties");
		property.load(fileread);
		
		String user=property.getProperty("username");
		String passwrd=property.getProperty("password");
		System.out.println("Encrypt file");
		String encryptUser=encode.encrypt(user);
		String encryptPass=encode.encrypt(passwrd);
		System.out.println(encryptUser);
		System.out.println(encryptPass);
		FileWriter filewrite=new FileWriter("encryptData.properties");
		property.setProperty("username", encryptUser);
		property.setProperty("password", encryptPass);
		property.store(filewrite, null);
		System.out.println("Encrypt file created ");
		System.out.println(" \n \n ");
		System.out.println("Decrypt data from properties file");
		FileReader readFile=new FileReader("encryptData.properties");
		property.load(readFile);
		String decUser=property.getProperty("username");
		String decPass=property.getProperty("password");
		String decryptUser=encode.decrypt(decUser);
		String decryptPass=encode.decrypt(decPass);
		System.out.println(" Username "+decryptUser);
		System.out.println(" Password "+decryptPass);
		
		
		
	}
}
