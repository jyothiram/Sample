package com.encoder.protector;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;

public class HmacEncoder
{
	String algorithm="HmacSHA256";
	String encode(String str) throws NoSuchAlgorithmException, InvalidKeyException
	{
		Mac hmac=Mac.getInstance(algorithm);
		SecretKeySpec key=new SecretKeySpec(str.getBytes(), algorithm);
		hmac.init(key);
		byte[] hmacBytes=hmac.doFinal(str.getBytes());
		String s=new String(Base64.getEncoder().encodeToString(hmacBytes));
		return s;
	}
	
	public static void main(String[] args) throws InvalidKeyException, NoSuchAlgorithmException, IOException
	{
		
		HmacEncoder hmacencode=new HmacEncoder();
		Properties property=new Properties();
		FileReader fileread=new FileReader("Hmacencrypt.properties");
		property.load(fileread);
		
		String url=property.getProperty("url");
		String passwrd=property.getProperty("password");
		System.out.println("Encrypt file");
		String encryptUrl=hmacencode.encode(url);
		String encryptPass=hmacencode.encode(passwrd);
		System.out.println(encryptUrl);
		System.out.println(encryptPass);
		FileWriter filewrite=new FileWriter("hmacencryptData.properties");
		property.setProperty("username", encryptUrl);
		property.setProperty("password", encryptPass);
		property.store(filewrite, null);
		System.out.println("HMAC Encrypt file created ");
		System.out.println(" \n \n ");
		
	}
}
