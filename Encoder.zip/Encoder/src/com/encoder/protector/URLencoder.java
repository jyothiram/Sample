package com.encoder.protector;
import java.io.*;
import java.net.*;
import java.util.Properties;

public class URLencoder 
{
	String encr(String str) throws UnsupportedEncodingException
	{
		String a=URLEncoder.encode(str, "UTF-8");
		
		
		return a;
		
	}
	String decr(String str) throws UnsupportedEncodingException
	{
		String da=URLDecoder.decode(str, "UTF-8");
		
		return da;
	}
	public static void main(String[] args) throws IOException 
	{
		URLencoder encoder=new URLencoder();
		Properties property=new Properties();
		FileReader urlfileRead=new FileReader("url.properties");
		property.load(urlfileRead);
		String urlRead=property.getProperty("URL");
		String encUrlRead=encoder.encr(urlRead);
		
		System.out.println("Creation of URL Encrypted property file \n ");
		System.out.println("URL - "+encUrlRead);
		FileWriter writeFile=new FileWriter("urldecrypt.properties");
		property.setProperty("URL", encUrlRead);
		property.store(writeFile, null);
		System.out.println("Encrypted URL file created succesfully \n");
		
		System.out.println("Decrypt the URL from decrypt file");
		
		FileReader urlDecryptfile=new FileReader("urldecrypt.properties");
		property.load(urlDecryptfile);
		String urldecryptString=property.getProperty("URL");
		String urlnormal=encoder.decr(urldecryptString);
		System.out.println(" URL - "+urlnormal);
		
	}
}
